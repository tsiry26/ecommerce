/**
 * Created by wap17 on 20/02/15.
 */

$(function(){
    $("#prix").on("click", myScript);
    $("#valider").on("click", retourScript);
    $(".btn").on("click", recupval);
});


function myScript (){
    $("#container").addClass("sombre");
    $("#divprice").addClass('show');
}

function retourScript(){
    $("#container").removeClassName("sombre");
    $("#divprice").removeClassName('show');
}

function recupval()
{
    var contenu=$(this).attr('name');
    var config= { url:base_url+"index.php/home/panierProduct/" + contenu};
    $.ajax(config).done(showPanier).fail(ajaxError);
}
function showPanier(data)
{
    data=JSON.parse(data);
        $('#share').prepend('<tr><td>'+data[0]['prix']+'</td><td>'+data[0]['name']+'</td></tr>');
}

function ajaxError()
{
    console.log("Erreur ajax");
}
