<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
session_start();

class Home extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function index()
    {
            if(empty($_SESSION['login']) == false)
            {
                $this->load->model("Model_user", '', true);
                $product = $this->Model_user->get_product();
                $this -> load -> view('top');
                $this -> load -> view('homepage', array('res'=>$product));
                $this -> load -> view('bottom');
            }
            else
            {
                redirect("/user/login");
            }

    }

    public function oneProduct($id)
    {
        $this->load->model("Model_user", '', true);
        $product = $this->Model_user->getone_product($id);
        $this -> load -> view('top');
        $this -> load -> view('oneProduct', array('res'=>$product));
        $this -> load -> view('bottom');
    }

    public function panierProduct($id)
    {

        $this->load->model("Model_user", '', true);
        $product = $this->Model_user->getone_product($id);
        echo json_encode($product);
    }

    public function priceProduct()
    {
        $this->load->model("Model_user", '', true);
        $pricemax = $this->Model_user->getprice_max();

        $min=0;
        $max=intval($pricemax[0]['maxi']);

        if(empty($_GET['price1'])==false && empty($_GET['price2'])==false )
        {
            $min=$_GET['price1'];
            $max=$_GET['price2'];
        }
        if(empty($_GET['price1']) && empty($_GET['price2'])==false)
        {
            $min=$_GET['price2'];
            $max=$_GET['price2'];
        }
        if(empty($_GET['price2']) && empty($_GET['price1'])==false)
        {
            $min=$_GET['price1'];
            $max=$_GET['price1'];
        }

        $this->load->model("Model_user", '', true);
        $product = $this->Model_user->getprice_product($min, $max);
        $this -> load -> view('top');
        $this -> load -> view('homepage', array('res'=>$product));
        $this -> load -> view('bottom');
    }

    public function searchProduct()
    {
        if (empty($_POST['browser'])==false)
        {
            $id=$_POST['browser'];
        }

        $this->load->model("Model_user", '', true);
        $product = $this->Model_user->getone_product($id);
        $this -> load -> view('top');
        $this -> load -> view('homepage', array('res'=>$product));
        $this -> load -> view('bottom');
    }

    public function ctgProduct($ctg)
    {
        $this->load->model("Model_user", '', true);
        $product = $this->Model_user->get_categorie($ctg);
        $this -> load -> view('top');
        $this -> load -> view('ctgProduct', array('res'=>$product, 'ctg'=>$ctg));
        $this -> load -> view('bottom');
    }

    public function pricectgProduct($ctg)
    {

        $this->load->model("Model_user", '', true);
        $pricemax = $this->Model_user->getprice_max();

        $min=0;
        $max=intval($pricemax[0]['maxi']);

        if(empty($_GET['price1'])==false && empty($_GET['price2'])==false )
        {
            $min=$_GET['price1'];
            $max=$_GET['price2'];
        }
        if(empty($_GET['price1']) && empty($_GET['price2'])==false)
        {
            $min=$_GET['price2'];
            $max=$_GET['price2'];
        }
        if(empty($_GET['price2']) && empty($_GET['price1'])==false)
        {
            $min=$_GET['price1'];
            $max=$_GET['price1'];
        }

        $this->load->model("Model_user", '', true);
        $product = $this->Model_user->getprice_categorie($ctg, $min, $max);
        $this -> load -> view('top');
        $this -> load -> view('ctgProduct', array('res'=>$product, 'ctg'=>$ctg));
        $this -> load -> view('bottom');
    }

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */